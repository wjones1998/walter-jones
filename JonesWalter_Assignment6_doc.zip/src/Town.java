public class Town implements Comparable<Town>{
	private String townName=null;
	private Town templateTown;
	private Town town;

	public Town(String name) {
		this.townName=name;
	}
	public Town(Town templateTown) {
		this(templateTown.townName);
	}

	@Override
	public int compareTo(Town o) {
		if(equals(o)==true) {
	
			return 0;}
		else if(townName.hashCode()-o.hashCode()>0) {
			return 1;
		}
		else { 
			return -1;
		}
	}
	
	public int hashCode() {
		return townName.hashCode();
	}
	
	public boolean equals(Object object) {
		if(townName.equals(object.toString()))
				return true;
		else return false;
	}
	public String getName() {
		return townName;
	}
	
	public String toString() {
		return getName();
		
	}
	
	protected class Road{
		private Road vertex;
		private int weight;
		
		protected Road(Road endVertex, int edgeWeight) {
			this.vertex=endVertex;
			this.weight=weight;
		}
		protected Road getEndRoad() {
			return vertex;
		}
		protected int getWeight() {
			return weight;
		}
	}
}
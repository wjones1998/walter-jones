/**
	 * The purpose of this class is to model a television
	* Walter Jones 2/19/2020
	 * @author wjones94
	 *
	 *
	 *
	 */

public class Television {
		 /**
		 * . The manufacturer attribute will hold the brand name. 
		 */
	final String Manufacturer;
		/**
		 * will hold the size of the television screen.
		 */
		final int ScreenSize;
		/**
		 * will hold the value true if the power is on, and false if the power is off.
		 */
		boolean powerOn;
		/**
		 *  will hold the value of the station that the television is showing.
		 */
		int Channel;
		/**
		 * will hold a number value representing the loudness (0 being no sound).

	    * The constructor below takes the brand name and size of the screen as arguments and colects the informations from the driver to put into the selected fields.
	    * @param manufacturer
	    * @param ScreenSize
	    */
		int Volume;
		
	   public Television(String Manufacturer, int ScreenSize) {

		  this.Manufacturer = Manufacturer;
		  this.ScreenSize = ScreenSize;
		
		  powerOn = false;
		  Volume = 20;
		  Channel = 2;

	}
	     /**
	      * This header returns the volume of the TV.
	      * @return
	      */
	     public int getVolume() {
		   return Volume;
	}
	      /**
	       *This header returns the Channel that the TV is on.
	       * @return
	       */
	     public int getChannel() {
		   return Channel;
	  }
		
	     /**
	      * this header returns the screen size of the television.
	      * @return
	      */
	     public int getScreenSize() {
	    	 return ScreenSize;
	     }
	     
	     /**
		 * This returns the brand name of the TV.
		 * @return
		 */
	     public String getManufacturer() {
		   return Manufacturer;
	   }
	     /**
	      * This header accepts a value and sets the TV to that value.
	      * @param Channel
	      */
	     public void setChannel(int Channel) {
	    	 this.Channel = Channel;
	     }
	    	 /**
	    	  * this header decides if the TV is turned off or on.
	    	  */
	     public void power() {
	    	 powerOn = !powerOn;
	    	 
	     }
	     /**
	      * This header increases the volume of the TV by one
	      */
	      public void increaseVolume() {
	    	   Volume ++;
	      }
	      
	      /**
	       * This header decreases the volume of the TV by 1.
	       */
	      public void decreaseVolume() {
	    	   Volume --;
	    	   }
	}




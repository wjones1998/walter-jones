package assignment1;

public class WeakPasswordException extends Exception {
	/**
	 * 
	 * message displayed if the password is within 6 and 10 characters long.
	 * 
	 */
	
  public WeakPasswordException() {
	  super("Password is ok but weak, a strong password is 10 characters");
	  
  }
  
  public WeakPasswordException(String message) {
	  super(message);
	  
  }
}

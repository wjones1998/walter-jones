package assignment1;

/**
 * 
 * @author Lumpe
 *message displayed if no digit is found within the password.
 */

public class NoDigitException extends Exception {
	public NoDigitException() {
		
		super("Must contain at least one numeric character");
		
	}

	public NoDigitException(String message) {
		
		super(message);
	}
	
}

package assignment1;

public class NoLowerAlphaException extends Exception {

	
	/**
	 * the message displayed if no lower case is found in the password.
	 *  
	 */
	public NoLowerAlphaException() {
		
		super("Must contain one lowercase aplha character.");
	}
	
	public NoLowerAlphaException(String message) {
		
		super(message);
		
	}
	
}

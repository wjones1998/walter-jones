package assignment1;

public class LengthException extends Exception {
	
	/**
	 *  message displayed if the password has less than 6 characters.
	 *  
	 */
	public LengthException() {
		
		super("Length must be greater than 6; a strong password will contain at least 10 characters");
	}
	
	public LengthException(String message) {
		
		super(message);
	}

}

package assignment1;

public class InvalidSequenceException extends Exception {

	/**
	 * password displayed if the password violates the sequence rules.
	 */
	
      public InvalidSequenceException() {
    	  
    	  super("May not have more than 2 of the same charatcers in sequence");
      }
	
      public InvalidSequenceException(String message) {
    	     super(message);
      }
}

package assignment1;

public class NoUpperAlphaException extends Exception {

	
	/**
	 * 
	 * message displayed if the password does not contain a upper case character.
	 */
	public NoUpperAlphaException() {
		super("Must contain at least one upper case alpha charatcer");
		
	}
	
	 public NoUpperAlphaException(String message) {
		 
		 super(message);
		 
	 }
	 
}

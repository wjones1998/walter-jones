package assignment1;

import java.util.ArrayList;
import java.util.Scanner;



public class PasswordCheckerUtility {
	   public static void main(String[] args)
	   {
		   String name1 = "AFCNh57";
		   String name2 = "aFCNh57";
		   String name3 = "$BTCG";
		   String name4 = "KKKKK";
		   String name5 = "kkkk%";
		   
		  System.out.println(hasBetweenSixAndNineChars(name5));
		   try {
			   
			 System.out.print(hasSameCharInSequence(name4));
			
		} catch (InvalidSequenceException e) {
			
			e.printStackTrace();
		}
		   
		 
		   
	   }
	
	public PasswordCheckerUtility() {
		
		
	}
	
	/**
	 * Checks if both passwords match each other.
	 * 
	 */
	public static void comparePasswords(String password,String passwordConfirm)throws UnmatchedException{
		
		if(password != passwordConfirm) {
			throw new UnmatchedException();
			
		} 
		
		
	}
	
	
	 /**
	  * 
	  * checks if the passwords are the same.
	  * @ return  returns true if the passwords are the same , otherwise return false.
	  */
	public static boolean comparePasswordsWithReturn(String password,String passwordConfirm) {
		
		if(password == passwordConfirm) {
			return true;
		} else {
			return false;
		}
		
	}
	
	
	public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords){
		
	      File myObj = new File("passwords.txt");
	      Scanner myReader = new Scanner(myObj);
	      while (myReader.hasNextLine()) {
	    passwords = myReader.nextLine();
	        System.out.println(passwords);
	      }
	      myReader.close();

	}
	

	/**
	 * 
	 * checks if the password contains between six and nine characters.
	 *  @ return return  true if the passwords is within the range and false if not.
	 */
	
	public static boolean hasBetweenSixAndNineChars(String password) {
		
		if(password.length()>5 && password.length()<10) {
			return true;
		} else 
			return false;
		
	}
	
	/**
	 *  checks if the password contains at least one digit.
	 * 
	 * @param password
	 * @return returns true if the password contains one digit else throws exception.
	 * @throws NoDigitException displays error message for containing at least 1 digit.
	 */
	
	public static boolean hasDigit(String password)
           throws NoDigitException{
		
		if(password.indexOf('0')>-1) {
			return true;
			} else if(password.indexOf('1')>-1) {
				return true;
		} else if(password.indexOf('2')>-1) {
			return true;
		}else if(password.indexOf('3')>-1) {
			return true;
		} else if(password.indexOf('4')>-1) {
			return true;
		}else if(password.indexOf('5')>-1) {
			return true;
		} else if(password.indexOf('6')>-1) {
			return true;
		} else if(password.indexOf('7')>-1) {
			return true;
		} else if(password.indexOf('8')>-1) {
			return true;
		} else if(password.indexOf('9')>-1) {
			return true;
		} else {
			throw new NoDigitException();
		}
		
		
	}
	
	/**
	 *  checks if the password has one lower case letter.
	 * @param password
	 * @return returns true if the password contains one lower case letter and throws exception if it does  
	 * not.
	 * @throws NoLowerAlphaException the exception displays the no lower case message. 
	 */
	public static boolean hasLowerAlpha(String password)
            throws NoLowerAlphaException{
		boolean hasLowercase = !password.equals(password.toUpperCase());
		if(hasLowercase == false) {
			throw new NoLowerAlphaException();
		} else {
			return true;
		}
			
	}
	
	/**
	 * checks if the password contains an upper case letter.
	 * @param password 
	 * @return return true if the password contains an upper case letter else throws exception.
	 * @throws NoUpperAlphaException, the exception prints out the for not having an upper case letter within the password.
	 */
	
	public static boolean hasUpperAlpha(String password)
            throws NoUpperAlphaException {
		
		boolean hasUppercase = !password.equals(password.toLowerCase());
		
		if(hasUppercase == false) {
			throw new NoUpperAlphaException();
		} else {
			return true;
		}
		
		
	}
	
	/**
	 *  checks if the password contains a special character.
	 * @param password
	 * @return returns true if the password contains a special character, if the password does not 
	 * contain a special character return false.
	 * @throws NoSpecialCharacterException, displays the error message for not containing a special character in a password.
	 */
	
	public static boolean hasSpecialChar(String password)
            throws NoSpecialCharacterException{
		boolean hasSpecial   = !password.matches("[A-Za-z0-9 ]*");
		
		if(hasSpecial == false){
			throw new NoSpecialCharacterException();
		} else {
			return true;
		}
		
	}
	
	
	/**
	 *  checks if the password is at least 6 or more characters long
	 * @param password
	 * @return return true if the password is 6 or more characters and return false if the password 
	 * is less than 6 characters.
	 * @throws LengthException prints out the error message for password being the incorrect length.
	 */
	
	public static boolean isValidLength(String password)
            throws LengthException{
		
		 if(password.length()<6) {
			 throw new LengthException();
		 } else {
			 return true;
		 }
		
	}
	
	/**
	 *  
	 * @param password checks the password is it contain two of the same characters  in a row.
	 * @return return false if the password does have two of the same characters in a row, also throw exception.
	 * @throws InvalidSequenceException display error message displaying error in passwords sequence.
	 */
	
	public static boolean hasSameCharInSequence(String password)
            throws InvalidSequenceException{
		
		
		boolean hasSameChar = !password.matches("(?!.*([A-Za-z0-9])\\1{2})[A-Za-z0-9]+");
		
		if(hasSameChar==true) {
			return false;
		}
		
		 throw new InvalidSequenceException();
		
		
		    }
	
	/**
	 * 
	 * @param password checks if the password is valid by checking if the password passed all of the 
	 * rules above.
	 * @return returns true if the password passed all of the methods , returns false if one method fails
	 * @throws LengthException displays the error message for incorrect length.
	 * @throws NoUpperAlphaException displays the message for not continuing a upper case letter.
	 * @throws NoLowerAlphaException display error message for not containing an lower case letter.
	 * @throws NoDigitException display the error message for not containing a digit.
	 * @throws NoSpecialCharacterException display error message for not containing a special character.
	 * @throws InvalidSequenceException display error message for not following sequence rules.
	 */
	
	public static boolean isValidPassword(String password)
            throws LengthException, NoUpperAlphaException, NoLowerAlphaException, 
            NoDigitException,NoSpecialCharacterException,InvalidSequenceException {
		
		if(hasDigit(password) && hasLowerAlpha(password) && hasUpperAlpha(password)
			&&	hasSpecialChar(password) && isValidLength(password) && hasSameCharInSequence(password) == true) {
			return true;
		} 
			if( isValidLength(password)== false) {
			throw new LengthException();
		} 
		
		if(hasUpperAlpha(password)==false) {
			throw new NoUpperAlphaException();
		}
		
		if( hasLowerAlpha(password)==false) {
			throw new NoLowerAlphaException();
		}
		
		
		if(hasDigit(password)==false) {
			throw new NoDigitException();
		}
		
		
		if(hasSpecialChar(password)==false) {
			throw new NoSpecialCharacterException();
		}
		
		if( hasSameCharInSequence(password)==false) {
			throw new InvalidSequenceException();
		}
		
		return false;
	}
		
	/**
	 * 
	 * @param password if the password is within 6 and 10 it is accepted but the password would be defined as weak.
	 * @return return true if the password is between 6 and 10.
	 * @throws WeakPasswordException display the password as weak but OK to use.
	 */
	public static boolean isWeakPassword(String password)
            throws WeakPasswordException{
		
		if(password.length()>6 && password.length()<10) {
			return true;
			
		} 
		
		throw new WeakPasswordException();
		}
	}
	
	
	

package assignment1;

public class NoSpecialCharacterException extends Exception {

	
	/**
	 * message displayed if no special characters are found within a password.
	 * 
	 */
	public NoSpecialCharacterException() {
		
		super("Must contain at least one special charatcer.");
		
	}
	  
	public NoSpecialCharacterException(String message) {
		
		super(message);
	}
	
}

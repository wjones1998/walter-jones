package assignment_4;

public class CourseDBElement implements Comparable{


	private String courseID;
	private int crn;
	private int numOfCredits;
	private String roomNum;
	private String instucName;
	
	/**
	 *  default constructor
	 */
	public CourseDBElement() {
		courseID = "";
	    crn = 0;
	    numOfCredits =0;
	    roomNum = "";
		instucName = "";
		
	}
      /**
       *  constructor methods
       * @param courseID course name
       * @param crn    course number
       * @param numOfCredits how many credits the course is worth
       * @param roomNum  room number
       * @param instucName the instructor name
       */
 public CourseDBElement(String courseID, int crn,int numOfCredits,String roomNum, String instucName ) {
	 
	 this.courseID = courseID;
	 this.roomNum = roomNum;
	 this.instucName = instucName;
	 this.crn = crn;
	 this.numOfCredits = numOfCredits;
	 
 }

 
 /**
  *  returns CRN of DBE.
  * @return returns the CRN
  */
public int getCRN() {
		return crn;
	}


/**
 *  sets the value of CRN from DBE.
 * @param input
 */
	public void setCRN(int input) {
		  crn = input;
	}

	
	
     /**
      * changes the CRN from integer to String.
      * @returns returns the CRN as a String.
      */
	public int hashCode() {
		String code = Integer.toString(crn);
		return code.hashCode();
	}
	
       
	public int compareTo(CourseDBElement element) {
		return this.compareTo(element);
	}
	
	
	
	public String toString() {
		return "\nCourse:" + courseID + "\nCRN:" + crn + "\n Number of Credits:" + numOfCredits
				+ "\n Instructor name:" + instucName + "\nRoom:" + roomNum;
		
		
}
	}
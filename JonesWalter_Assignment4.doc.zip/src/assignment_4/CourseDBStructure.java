package assignment_4;

import java.io.IOException;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {
	protected LinkedList<CourseDBElement>[] hashTable;
	
	/**
	 *  creates a hashTable with the estimated size
	 * @param size 
	 */
	public CourseDBStructure(int size) {
		hashTable = new LinkedList[size];
		
	}
	/**
	 *  the String is used for testing while the size is the size of the hashTable
	 * @param testing
	 * @param size
	 */
	public CourseDBStructure(String testing, int size) {
		hashTable = new LinkedList[size];
	}
	
	@Override
	/**
	 * search the Hash table for the CDE element if the element does not exsist in the
	 * Hash table insert it into the Hash table. 
	 * 
	 * @param element The CDE to be added
	 */
	public void add(CourseDBElement element) {
		
		 int hashIndex = element.hashCode() % hashTable.length;
		  if(hashTable[hashIndex]== null) {
			   LinkedList<CourseDBElement> input = new LinkedList<CourseDBElement>();
			   input.add(element);
			   hashTable[hashIndex] = input;
		  } else {
			  
			 hashTable[hashIndex].add(element);
			   
		  }
				 
		
	}

	@Override
	/**
	 *  using hash code of the CRN of the CourseDatabaseElement class check if the hash table contains the 
	 *  code and return it, If not throw IOException.
	 * @param crn
	 * @return returns the CourseDatabaseElement , null , or throws IOexception
	 * @throws IOException
	 * 
	 */
	public CourseDBElement get(int crn) throws IOException {
		String hCode = Integer.toString(crn);
		int hashIndex = hCode.hashCode() % hashTable.length;
		if(hashTable[hashIndex]==null) {
			throw new IOException();
		} else {
			for (int i = 0; i < hashTable[hashIndex].size(); i++) {
				if (hashTable[hashIndex].get(i).getCRN()==crn) {
					return hashTable[hashIndex].get(i);
				}
		   }
			throw new IOException();
		}	  
		  
	}

	@Override
	/**
	 * @returns Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	 */
	public int getTableSize() {
      return hashTable.length;
	}
	

}

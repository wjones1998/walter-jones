package assignment_4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
 private CourseDBStructure data = new CourseDBStructure(20);
	
	@Override
	/**
	 *  using the Add method within the CBE class adds the element to the 
	 *  Structure. 
	 * 
	 * @param id,crn,credits, room number, instructor.
	 */
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		CourseDBElement element = new CourseDBElement(id,crn,credits,roomNum,instructor);
		data.add(element);
		
		
	}

	@Override
	/**
	 *    return the crn of the data.
	 * 
	 * @param crn
	 * @return returns a Integer or Null.
	 */
	public CourseDBElement get(int crn) {
		
		try {
			return data.get(crn);
		} catch (IOException e) {
	
			e.printStackTrace();
		}
		return null;
	}

	@Override
	/**
	 *  reads  the input from a file and adds them to the structure.
	 * @param File input
	 */
	public void readFile(File input) throws FileNotFoundException {
		Scanner sc = new Scanner(input);
		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			String[] lineArray = line.split(" ");
			int size = lineArray.length;
			boolean middleName = false;
			String courseID = lineArray[0];
			int crn = Integer.parseInt(lineArray[1]);
			int credits = Integer.parseInt(lineArray[2]);
			for (int i = 0; i < lineArray.length; i++) {
				if (lineArray[i].charAt(lineArray[i].length()-1)=='.' && lineArray[i].length()==2) {
					middleName = true;
				}
			}
			if (!middleName) {
				String roomNum = "";
				for (int i = 3; i < size-2; i++) {
					roomNum += lineArray[i];
				}
				String teacher = lineArray[size-2] + lineArray[size-1];
				this.add(courseID, crn, credits, roomNum, teacher);
			}else {
				String roomNum = "";
				for (int i = 3; i < size-3; i++) {
					roomNum += lineArray[i];
				}
				String teacher = lineArray[size-3] + lineArray[size-2] + lineArray[size-1];
				this.add(courseID, crn, credits, roomNum, teacher);
			}
		}
		
	}

	@Override
	/** 
	 *  prints out the database elements.
	 * @return returns database elements
	 */
	public ArrayList<String> showAll() {
		ArrayList<String> display = new ArrayList<String>();
		for (LinkedList<CourseDBElement> list : data.hashTable) {
			if(list != null) {
				for (int i = 0; i < list.size(); i++) {
					String course =  list.get(i).toString();
					display.add(course);
		     	}
			}	
		}
		return display;
	}

}

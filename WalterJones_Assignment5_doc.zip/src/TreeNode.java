
public class TreeNode <T> {
	
	protected TreeNode<T> leftChild;
	
	protected TreeNode<T> rightChild;
	
	protected T data;
	
	
	public TreeNode(T dataNode) 
	{
		this.data = dataNode;
		
		this.leftChild = null;
		
		this.rightChild = null;
		
	}
	
	public T setData(T data) 
	{
		return data;
		
	}
	
	public void setRight (TreeNode<T> right) 
	{
		
		this.rightChild=right;
		
	}
	
	public void setLeft(TreeNode<T> left) 
	{
		
		this.leftChild = left;
		
		
	}
	
	public TreeNode<T> getLeft()
	
	{
		
		return leftChild;
		
	}
	
public T getData() 
	
	{
		
		return data;
		
	}

	
	
	public TreeNode<T> getRight()
	
	{
		
		return rightChild ;
	}
	
	@SuppressWarnings("unchecked")
	public TreeNode(TreeNode<String> node) 
	
	{
		this.leftChild= new TreeNode<>(node.leftChild);
		
		this.rightChild= new TreeNode<>(node.rightChild);
		
		this.data = (T) node.data;
		
	}
	
}